import $ from 'jquery';
import './css/teste.scss';



$(function(){

$('#botao').on('click', function(){
  $('h1').html("ola mundo alterado");
  $('#imagem').attr('src', cas);
  
  });

});

