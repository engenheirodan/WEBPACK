const path = require('path');

module.exports = {
  entry: './src/index.js',
  output: {
    path: path.resolve(__dirname, 'dist'),
    filename: 'main.js',
  },
  mode: "production",
  module:{
    rules: [
      { test: /\.css$/, use:['style-loader', 'css-loader' ]},
      { test: /\.png$/, use:[ 'file-loader' ]},
      { test: /\.scss$/, use:[ 'sass-loader', 'style-loader', 'css-loader' ]}

  ]
  }

};